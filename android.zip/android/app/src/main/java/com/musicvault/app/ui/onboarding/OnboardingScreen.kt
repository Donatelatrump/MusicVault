package com.musicvault.app.ui.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import com.musicvault.app.ui.theme.VaultColors

@Composable
fun OnboardingScreen(
    onCompleto: (generos: Set<String>, artistas: Set<String>) -> Unit,
    onSkip: () -> Unit
) {
    var generos by remember { mutableStateOf(emptySet<String>()) }
    var artistas by remember { mutableStateOf(emptySet<String>()) }

    Column {
        Text(
            text = "Bienvenido a MusicVault",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = VaultColors.TextPrimary
        )
        Text(
            text = "Ayúdanos a personalizar tu experiencia",
            fontSize = 16.sp,
            color = VaultColors.TextTertiary
        )
        Text(
            text = "Selecciona tus géneros favoritos",
            fontSize = 16.sp,
            color = VaultColors.TextPrimary
        )
        Text(
            text = "Selecciona tus artistas preferidos",
            fontSize = 16.sp,
            color = VaultColors.TextPrimary
        )
        Row(
            horizontalArrangement = Arrangement.End
        ) {
            androidx.compose.material3.Button(
                onClick = onSkip
            ) {
                Text("Saltizar", fontSize = 14.sp)
            }
            androidx.compose.material3.Button(
                onClick = { onCompleto(generos, artistas) }
            ) {
                Text("Comenzar", fontSize = 14.sp, color = VaultColors.OnAccent)
            }
        }
    }
}